test = {   'name': 'q2_2_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(rise_to_power) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(rise_to_power) == 8\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> # Did you find all the unique paths;\n'
                                               '>>> # to the throne;\n'
                                               ">>> all(np.sort(rise_to_power) == np.array(['Appointment by Army', \n"
                                               "...                                         'Appointment by Emperor',\n"
                                               "...                                         'Appointment by Praetorian Guard',\n"
                                               "...                                         'Appointment by Senate',\n"
                                               "...                                         'Birthright', 'Election',\n"
                                               "...                                         'Purchase',\n"
                                               "...                                         'Seized Power']))\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
