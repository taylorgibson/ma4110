test = {   'name': 'q2_2_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(path_to_throne) == tables.Table\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> path_to_throne.num_columns == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> path_to_throne.num_rows == 8\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
