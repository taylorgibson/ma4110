test = {   'name': 'q1_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> movies.num_columns == 6\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> # Did you add the Tickets Sold column;\n'
                                               ">>> movies.labels == ('Year', 'Average Ticket Price', 'Total Gross', 'Number of Movies', '#1 Movie', 'Tickets Sold')\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
