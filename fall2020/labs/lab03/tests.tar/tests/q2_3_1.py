test = {   'name': 'q2_3_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(ceo_income) == tables.Table\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> ceo_income.num_rows == 102\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> ceo_income.num_columns == 9\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
