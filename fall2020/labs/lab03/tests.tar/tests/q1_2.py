test = {   'name': 'q1_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(gross_in_dollars) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(tix_sold) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Did you convert Total Gross to millions;\n>>> sum(tix_sold) == 46570958566.29024\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
