test = {   'name': 'q2_3_2',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> avg_ceo_total_pay == sum(ceo_income.column('Total Pay'))/ceo_income.num_rows\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
