test = {   'name': 'q1_4',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> # Did you sort the movies table;\n>>> movies.first('Tickets Sold') == 1578448275.8620691\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
