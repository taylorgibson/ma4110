test = {   'name': 'q2_2_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(emperors) == tables.Table\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> emperors.num_rows == 68\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> emperors.num_columns == 16\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
