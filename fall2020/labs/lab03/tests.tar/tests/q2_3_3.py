test = {   'name': 'q2_3_3',
    'points': 1,
    'suites': [   {   'cases': [{'code': ">>> pct_above_avg == ceo_income.where('Total Pay', are.above(avg_ceo_total_pay)).num_rows/ceo_income.num_rows\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
