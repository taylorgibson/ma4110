test = {   'name': 'q1_1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> type(movies) == tables.Table\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> movies.num_rows == 36\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
